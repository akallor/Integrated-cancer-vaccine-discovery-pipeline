Module 1 - assets/ rule tables (both are plain TSV, edit freely)
================================================================

origin_patterns.tsv   priority <TAB> origin_class <TAB> regex
  Lower priority = tested first; the first regex that matches the FASTA header wins. Regexes are
  matched case-insensitively against the whole header. Add a row to recognize a new header style,
  or raise a row's priority (lower number) to make it win over a more general pattern.
  An explicit `origin=<class>` token in a header ALWAYS overrides these patterns.

translation_rules.tsv origin_class <TAB> frames(1|3|6) <TAB> strand(forward|both|auto)
                      <TAB> genetic_code <TAB> min_aa_len <TAB> require_start <TAB> cds
  frames=1 = one forward frame; frames=3 = one strand (forward, or header strand when auto);
  frames=6 = both strands. genetic_code is an NCBI table (1=standard, 11=bacterial).
  cds=true: treat the record as an ALREADY-DEFINED ORF -> single frame, initiator codon rendered
  as M (non-AUG starts TTG/CTG/GTG... included, per Ribo-seq/GENCODE convention), terminal stop
  dropped. This is the lean choice for the MS search DB when the sequence IS the ORF (e.g. ncorf /
  Ribo-seq ncORFs). Leave cds=false for discovery classes that need multi-frame translation.
  'unknown' is the fallback (6-frame) and is always present.

  Frame policy (why it matters for the MS/MS search DB): every extra frame that isn't the real ORF
  inflates the target DB and the FDR penalty, which can bury true IDs. So emit the MINIMUM frames
  justified by annotation: defined ORFs (ncorf) -> cds=true (1 frame); genuinely unannotated
  transcript/region (ncrna, intronic, intergenic, erv) -> 6-frame discovery.

To add a brand-new origin end to end: (1) add a pattern row mapping its header to a class, and
(2) add a rule row for that class. No code change needed.

--- Frame policy (strand awareness) -------------------------------------------
Frame count follows what is KNOWN, not the origin label:
  cds=true       -> 1 frame  (annotated / Ribo-seq ORF; reading frame known)
  strand=forward -> 3 frames on the sense strand (sequence is transcript-oriented)
  strand=both    -> 6 frames (strand genuinely unknown)
  strand=auto    -> ADAPTIVE: 3 frames on the record's strand when known
                    (a header strand=+/- token, or the --stranded run flag); else 6 frames.
So a stranded RNA-seq origin (ncrna/erv/intronic/... with strand known) is 3-frame;
de novo / unstranded / genomic-window inputs fall back to 6-frame. Pass --stranded
(or emit strand=+/- in headers) to collapse the auto origins from 6 to 3.

--- FASTA-mode BLAST annotation (--reference) -----------------------------------
When --fasta records have no known coordinates, pass --reference <hg38.fa> (download the
latest UCSC/GENCODE hg38 primary assembly, e.g. hg38.fa, and place it here under assets/).
Module 1 BLASTs each record against it at 100% identity (blast_annotate.py) and rewrites the
header with chr:start-end and, if --gtf <gencode.gtf(.gz)> is given, gene name + biotype.
Provide a prebuilt BLAST DB via --blast_db to avoid re-running makeblastdb on the 3 GB genome:
    makeblastdb -in assets/hg38.fa -dbtype nucl -out assets/hg38   ->  --blast_db assets/hg38
biotype_map.tsv maps the gene biotype to origin/class (coding->cds/canonical, else ncorf/noncanonical).
